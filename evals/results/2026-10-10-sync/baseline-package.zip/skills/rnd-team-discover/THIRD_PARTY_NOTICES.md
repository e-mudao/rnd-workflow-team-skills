# Third-party methods

pm-skills: pm-product-discovery/skills/identify-assumptions-new/SKILL.md
Fixed commit: 18468a95b427e70e258b51389796367c6f684e7d
License: MIT, retained in references/upstream/pm-skills-LICENSE.txt
Adaptation: Retain risk categories, explicit confidence and proposed tests; apply only material categories to the current request. Copyable profile: use existing project artifacts/tools; runtime metadata and automatic gates are not required.

pm-skills: pm-product-discovery/skills/summarize-interview/SKILL.md
Fixed commit: 18468a95b427e70e258b51389796367c6f684e7d
License: MIT, retained in references/upstream/pm-skills-LICENSE.txt
Adaptation: Retain complete reading, current solution/problems, unknown fields and action items; use a compact collection brief. Copyable profile: use existing project artifacts/tools; runtime metadata and automatic gates are not required.

## Team collection adaptation

Forked from the copyable single-person collection at commit 082edfd. Retains fixed upstream method excerpts and licenses unchanged. Adds collection-synthesized team task ownership, assigned contributor scope, shared-artifact maintainers, isolated checkouts, handoff facts, integrated-version verification and designated release execution. Role names do not grant authority or exclusive task claims; existing project tools and authorizations apply.

## Adaptive team collection synthesis (2026-10-06)

Collection synthesis for team-scoped automatic role continuation and repair/recheck; task/version/subset checkpoints confirmed by the person authorized for that matter; recovery of pending/partial confirmations; phase-aware document and experiment review with actual maintainer plus role routing; goal/impact/scale selection, contextual reading and integrated-version evidence. Does not grant authority over another member or add runtime, approval or synchronization services. Fixed upstream sources and prior team adaptation remain unchanged.

## Team review corrections synthesis (2026-10-06)

Collection synthesis clarifying evidence-based withdrawal of false review findings by the current review-record maintainer, with version/reason/counterevidence and repair-assignment removal; genuine or disputed other-owner defects remain open. Checkpoints depend on actual unknowns, impact, recovery cost, verification dependencies and batch-delivery needs; multiple files/functions alone are insufficient. Clear local reversible migrations verifiable in one batch continue under existing task authorization. Existing stops and major decisions remain effective; no new runtime or authority is added.
