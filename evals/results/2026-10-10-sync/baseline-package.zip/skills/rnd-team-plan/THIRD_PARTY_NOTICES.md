# Third-party methods

superpowers: skills/writing-plans/SKILL.md
Fixed commit: 8ca22dba9a94f28898bbce59f2537ff4d87c747d
License: MIT, retained in references/upstream/superpowers-LICENSE.txt
Adaptation: Retain explicit files/interfaces/dependencies and checkable RED/GREEN tasks; replace orchestration and storage conventions. Copyable profile: use existing project artifacts/tools; runtime metadata and automatic gates are not required.

## Team collection adaptation

Forked from the copyable single-person collection at commit 082edfd. Retains fixed upstream method excerpts and licenses unchanged. Adds collection-synthesized team task ownership, assigned contributor scope, shared-artifact maintainers, isolated checkouts, handoff facts, integrated-version verification and designated release execution. Role names do not grant authority or exclusive task claims; existing project tools and authorizations apply.

## Adaptive team collection synthesis (2026-10-06)

Collection synthesis for team-scoped automatic role continuation and repair/recheck; task/version/subset checkpoints confirmed by the person authorized for that matter; recovery of pending/partial confirmations; phase-aware document and experiment review with actual maintainer plus role routing; goal/impact/scale selection, contextual reading and integrated-version evidence. Does not grant authority over another member or add runtime, approval or synchronization services. Fixed upstream sources and prior team adaptation remain unchanged.

## Team review corrections synthesis (2026-10-06)

Collection synthesis clarifying evidence-based withdrawal of false review findings by the current review-record maintainer, with version/reason/counterevidence and repair-assignment removal; genuine or disputed other-owner defects remain open. Checkpoints depend on actual unknowns, impact, recovery cost, verification dependencies and batch-delivery needs; multiple files/functions alone are insufficient. Clear local reversible migrations verifiable in one batch continue under existing task authorization. Existing stops and major decisions remain effective; no new runtime or authority is added.
