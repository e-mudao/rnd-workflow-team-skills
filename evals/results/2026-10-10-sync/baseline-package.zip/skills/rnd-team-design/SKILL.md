---
name: rnd-team-design
description: Use when an assigned change in a multi-person project needs user-flow, interaction, layout or accessibility decisions or rendered verification.
---

# 产品界面与交互设计

输入用户问题、规格、现有界面/设计系统和目标设备。负责必要的交互、视觉决定及观察证据。

## 多人任务边界

核对页面/组件任务负责人和共享设计约定。设计建议与真实观察交现行规格/计划维护人；实施由已分配的界面负责人完成。只做检查时不编辑实现；后端任务的 Agent 不因发现界面问题接管前端工作。

[接手、分工与交接字段](references/workflow.md) 使用项目现有记录；只有本地草稿时不声称已通知或同步给其他成员。

## 方法

1. 先查看实际页面或设计材料，明确用户任务、路径、状态和当前问题，沿用已选视觉与组件约定。
2. 检查主路径及加载、空、错误、权限、成功状态；给出具体改进，核对内容层级、键盘/焦点、对比度和响应式行为。
3. 检查请求只产出观察与建议，不修改页面实现。用户已授权实施时，按下一步落实必要决定，再由 build 实施有限改动，随后重新观察；同一 Agent 可以顺序切换职责。交互/布局/可访问性检查配合真实渲染和视觉审查，分别说明截图与操作证明的范围。
4. 先将改变用户行为的决定交 spec、实现安排交 plan，纳入当前依据后交 build 实施。在项目现有文档保存决定与证据，不要求额外搭建 UI 迭代平台。

## 核验与返回

交 reviewer/verify 当前状态和真实截图/操作证据。缺浏览器或可视材料就说明未验证，不能以格式检查或代码编译证明视觉质量。

参照 [协作约定](references/workflow.md)；保留 HumanLayer design-control-loop 的观察反馈循环，见 [固定来源](references/methods.md)。
