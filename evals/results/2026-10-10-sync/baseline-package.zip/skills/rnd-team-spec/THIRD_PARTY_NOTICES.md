# Third-party methods

github-spec-kit: templates/commands/specify.md
Fixed commit: 8d3f64cdccc877b6a297bc8167131103bb5b8ca0
License: MIT, retained in references/upstream/github-spec-kit-LICENSE.txt
Adaptation: Retain user scenarios, functional requirements, measurable success and ambiguity/quality checks; use one collection specification and stable acceptance IDs. Copyable profile: use existing project artifacts/tools; runtime metadata and automatic gates are not required.

## Team collection adaptation

Forked from the copyable single-person collection at commit 082edfd. Retains fixed upstream method excerpts and licenses unchanged. Adds collection-synthesized team task ownership, assigned contributor scope, shared-artifact maintainers, isolated checkouts, handoff facts, integrated-version verification and designated release execution. Role names do not grant authority or exclusive task claims; existing project tools and authorizations apply.

## Adaptive team collection synthesis (2026-10-06)

Collection synthesis for team-scoped automatic role continuation and repair/recheck; task/version/subset checkpoints confirmed by the person authorized for that matter; recovery of pending/partial confirmations; phase-aware document and experiment review with actual maintainer plus role routing; goal/impact/scale selection, contextual reading and integrated-version evidence. Does not grant authority over another member or add runtime, approval or synchronization services. Fixed upstream sources and prior team adaptation remain unchanged.

## Team review corrections synthesis (2026-10-06)

Collection synthesis clarifying evidence-based withdrawal of false review findings by the current review-record maintainer, with version/reason/counterevidence and repair-assignment removal; genuine or disputed other-owner defects remain open. Checkpoints depend on actual unknowns, impact, recovery cost, verification dependencies and batch-delivery needs; multiple files/functions alone are insufficient. Clear local reversible migrations verifiable in one batch continue under existing task authorization. Existing stops and major decisions remain effective; no new runtime or authority is added.
